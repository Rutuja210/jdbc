package dataaccess.dao;

import java.util.List;
import dataaccess.model.Employee;

public interface EmployeeDAO {
	public Employee getEmployeeById(int id);

	public List<Employee> getEmployees();

	public boolean createEmployee(Employee emp);
}
