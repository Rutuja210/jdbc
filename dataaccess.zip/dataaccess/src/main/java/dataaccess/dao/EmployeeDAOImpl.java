package dataaccess.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import dataaccess.model.Employee;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO{

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public Employee getEmployeeById(int id) {
			String sql = "SELECT * FROM EMPLOYEE WHERE ID = ?";
			Employee emp = jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<Employee>(Employee.class), id);
			return emp;
	}

	public List<Employee> getEmployees() {
		String sql = "SELECT * FROM EMPLOYEE";
		List<Employee> allEmployees = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Employee>(Employee.class));
		return allEmployees;
	}

	public boolean createEmployee(Employee emp) {
		try {
			String sql = "INSERT INTO EMPLOYEE VALUES (?, ?, ?)";
			jdbcTemplate.update(sql, emp.getId(), emp.getName(), emp.getCity());
			return true;
		} catch (DataAccessException e) {
			e.printStackTrace();
			return false;
		}
	}

}
