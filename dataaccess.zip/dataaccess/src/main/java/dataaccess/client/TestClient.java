package dataaccess.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import dataaccess.config.BeanConfig;
import dataaccess.model.Employee;
import dataaccess.service.EmployeeService;
import dataaccess.service.EmployeeServiceImpl;

public class TestClient {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(BeanConfig.class);
		EmployeeService service = context.getBean(EmployeeService.class);
		
		Employee emp = new Employee(110, "Robert", "Pirsig");
		service.createEmployee(emp);
		
		List<Employee> allEmployees = service.getEmployees();
		allEmployees.forEach(System.out::println);
		
		Employee fetchedEmployee = service.getEmployeeById(104);
		
		System.out.println(fetchedEmployee);
	}

}
