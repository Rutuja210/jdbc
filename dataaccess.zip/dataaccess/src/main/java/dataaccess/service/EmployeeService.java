package dataaccess.service;

import java.util.List;

import dataaccess.model.Employee;

public interface EmployeeService {
	public Employee getEmployeeById(int id);

	public List<Employee> getEmployees();

	public void createEmployee(Employee emp);

}
