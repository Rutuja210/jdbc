package dataaccess.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dataaccess.dao.EmployeeDAO;
import dataaccess.model.Employee;

// Can handle Transactions
@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeDAO dao;
	
	public Employee getEmployeeById(int id) {
		return dao.getEmployeeById(id);
	}

	public List<Employee> getEmployees() {
		return dao.getEmployees();
	}

	public void createEmployee(Employee emp) {
		boolean inserted = dao.createEmployee(emp);
	}
	// other methods
}
